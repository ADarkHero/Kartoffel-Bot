import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import org.jibble.pircbot.*;

public class KartoffelBotMain {
  public static void main(String[] args) throws Exception {
      
      String botname = "";
      String password = "";
      String channelName = "";
      String server = "";
      
      String fileName = "config/password.txt";
      String line = null;
      
                                        try {
                                                FileReader fileReader = new FileReader(fileName);

                                                BufferedReader bufferedReader = new BufferedReader(fileReader);

                                                while((line = bufferedReader.readLine()) != null) {
                                                    password = line;
                                                }	

                                                bufferedReader.close();			
                                            }
                                            catch(FileNotFoundException ex) {
                                                System.out.println(
                                                    "Unable to open file '" + fileName + "'");				
                                            }
                                            catch(IOException ex) {
                                                System.out.println("Error reading file '" + fileName + "'");
                                            }
                                        
     fileName = "config/channel.txt";
     line = null;
      
                                        try {
                                                FileReader fileReader = new FileReader(fileName);

                                                BufferedReader bufferedReader = new BufferedReader(fileReader);

                                                while((line = bufferedReader.readLine()) != null) {
                                                    channelName = line;
                                                }	

                                                bufferedReader.close();			
                                            }
                                            catch(FileNotFoundException ex) {
                                                System.out.println(
                                                    "Unable to open file '" + fileName + "'");				
                                            }
                                            catch(IOException ex) {
                                                System.out.println("Error reading file '" + fileName + "'");
                                            }
                                        
                                        
     fileName = "config/server.txt";
     line = null;
      
                                        try {
                                                FileReader fileReader = new FileReader(fileName);

                                                BufferedReader bufferedReader = new BufferedReader(fileReader);

                                                while((line = bufferedReader.readLine()) != null) {
                                                    server = line;
                                                }	

                                                bufferedReader.close();			
                                            }
                                            catch(FileNotFoundException ex) {
                                                System.out.println(
                                                    "Unable to open file '" + fileName + "'");				
                                            }
                                            catch(IOException ex) {
                                                System.out.println("Error reading file '" + fileName + "'");
                                            }
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
    KartoffelBot bot = new KartoffelBot();      // this starts your bot
    bot.setVerbose(true);             // enable debugging, useful during programming
    //bot.connect("localhost");  // connect to localhost
    bot.connect(server, 6667, password);  // connect to your IRC server (fill in your own)
    bot.joinChannel("#"+channelName);    // join your channel
  }
}