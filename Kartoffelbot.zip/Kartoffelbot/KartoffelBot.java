import org.jibble.pircbot.*;
import java.io.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.Timer;




public class KartoffelBot extends PircBot {
    
    int first = 0;
    
  public KartoffelBot() {
      String fileName = "config/botname.txt";
      String line = null;
      String botname = "";

                                        try {
                                                FileReader fileReader = new FileReader(fileName);

                                                BufferedReader bufferedReader = new BufferedReader(fileReader);

                                                while((line = bufferedReader.readLine()) != null) {
                                                    botname = line;
                                                }	

                                                bufferedReader.close();			
                                            }
                                            catch(FileNotFoundException ex) {
                                                System.out.println(
                                                    "Unable to open file '" + fileName + "'");				
                                            }
                                            catch(IOException ex) {
                                                System.out.println("Error reading file '" + fileName + "'");
                                            }
                                        
      
      
    this.setName(botname);          // use your own nick here
  }
  
  
  //Notiz: u.isOp() funktioniert nicht richtig auf Twitch. q.q
                          private static int cnt;

       
  
                          
  
	  public void onMessage(String channel, String sender, String login, String hostname, String message) {
			
		//Testcommand
			if (message.equals("!test")) {
			   sendMessage(channel, sender + " sagte: " + message);
			}
		
		//OP Rechte abfragen
			if (message.equals("!isop")) {
				User users[] = getUsers( channel );
				User u = null;

				for( User user : users ){
				   if( sender.equals( user.getNick() ) ){
					  u = user;
					  break;
				   }
                                   System.out.println("Test");
				}
			
				if ( u.isOp() || sender.equals("adarkhero") ){
                                    sendMessage(channel, "You currently have OP rights!");
                            }
				else {
                                    sendMessage(channel, "You currently have NO OP rights!");
                            }
			}
			
			
		//Standard "Reagiere auf Eingabe" Commands
			if (message.contains("!elektrotitte")) {
				message = message.substring(14);
			   sendMessage(channel, message + "s Titten sind elektrisch, BABY!");
			}
			
			if (message.contains("!hype")) {
				message = message.substring(6);
			   sendMessage(channel, message + " HYPE! FrankerZ");
			}
			
			if (message.equals("!cheesecake")) {
			   sendMessage(channel, "I like cheesecake!");
			}
			
			if (message.equals("!diaet")) {
			   sendMessage(channel, "Ich bin der große, böse Diätmeister!");
			}
			
			if (message.equals("!nicemen")) {
			   sendMessage(channel, "Nice men come last!");
			}
			
			if (message.equals("!picnic")) {
			   sendMessage(channel, "Picnic?! Picnic. FrankerZ");
			}
			
			if (message.equals("!warum")) {
			   sendMessage(channel, "Weil Baum!");
			}
			
			
		//Kick bei Badwords
			if (message.contains("fuck") || message.contains("sex")) {
			   kick(channel, sender);
			   sendMessage(channel, "Stahp using bad words!");
			}
                        
                //Raid                     
                        if (message.contains("!raid")) {
                                int msglength = message.length();
				message = message.substring(6);
                                sendMessage(channel, "How to raid: Copy the raid message, go to the raidtarget & paste the message there.");

                                if (msglength > 6){
                                    final String[] raidstuff = message.split(" ");
                                    
                                    User users[] = getUsers( channel );
				User u = null;

				for( User user : users ){
				   if( sender.equals( user.getNick() ) ){
					  u = user;
					  break;
				   }
				}
                                
                                
                                if (raidstuff[1] != null && (u.isOp() || sender.equals("adarkhero"))){
                                    int raidstufflength = raidstuff[0].length();
                                    raidstufflength++;
                                    String raidmsg = message.substring(raidstufflength);
                                    sendMessage(channel, "Raidtarget: http://www.twitch.tv/"+raidstuff[0]);
                                    sendMessage(channel, "Raidmessage: "+raidmsg);
                                }
                                }
                                
			}
                
                        
                //Rank
                        if (message.equals("!rank")){
                            int rank = 0;
            
                                        String fileName = "rank/"+sender+".txt";
                                        String line = null;

                                        try {
                                                FileReader fileReader = new FileReader(fileName);

                                                BufferedReader bufferedReader = new BufferedReader(fileReader);

                                                while((line = bufferedReader.readLine()) != null) {
                                                    System.out.println(line);
                                                    rank = Integer.parseInt(line);
                                                }	

                                                bufferedReader.close();			
                                            }
                                            catch(FileNotFoundException ex) {
                                                System.out.println(
                                                    "Unable to open file '" + fileName + "'");				
                                            }
                                            catch(IOException ex) {
                                                System.out.println("Error reading file '" + fileName + "'");
                                            }
                                        
                                        sendMessage(channel, "The rank of " + sender + " is " + rank + "!");
                        }
			
		
                //Rankup
			if (message.contains("!rankup")) {
				message = message.substring(8);
                                final String[] rankstuff = message.split(" ");
                                
			   User users[] = getUsers( channel );
				User u = null;

				for( User user : users ){
				   if( sender.equals( user.getNick() ) ){
					  u = user;
					  break;
				   }
				}
			
				if ( u.isOp() || sender.equals("adarkhero")){
					int rank = 0;
            
                                        String fileName = "rank/"+rankstuff[0]+".txt";
                                        String line = null;

                                        try {
                                                FileReader fileReader = new FileReader(fileName);

                                                BufferedReader bufferedReader = new BufferedReader(fileReader);

                                                while((line = bufferedReader.readLine()) != null) {
                                                    System.out.println(line);
                                                    rank = Integer.parseInt(line);
                                                }	

                                                bufferedReader.close();			
                                            }
                                            catch(FileNotFoundException ex) {
                                                System.out.println(
                                                    "Unable to open file '" + fileName + "'");				
                                            }
                                            catch(IOException ex) {
                                                System.out.println("Error reading file '" + fileName + "'");
                                            }



                                            int rankup = Integer.parseInt(rankstuff[1]);
                                            rank = rank+rankup;
                                            
                                            
                                            sendMessage(channel, rankstuff[0] + " is now rank " + rank + "!");

                                          //Rank in Datei schreiben
                                           try{
                                                FileWriter fstream = new FileWriter("rank/"+rankstuff[0]+".txt");
                                                BufferedWriter out = new BufferedWriter(fstream);
                                                out.write(rank+"");

                                                out.close();
                                            }catch (Exception e){
                                            System.err.println("Error: " + e.getMessage());
                                            }
				}
				else {
					sendMessage(channel, "You currently have NO OP rights!");
				}
			}
                        
                //Joinmsg
                        if (message.contains("!joinmsg")) {
				message = message.substring(9);
                                
                                            try{
                                                FileWriter fstream = new FileWriter("join/"+sender+".txt");
                                                BufferedWriter out = new BufferedWriter(fstream);
                                                out.write(message+"");

                                                out.close();
                                            }catch (Exception e){
                                            System.err.println("Error: " + e.getMessage());
                                            }
                                                                          
			   sendMessage(channel, sender + " set the joinmessage \""+message+"\"!");
			}
                 
             //Undercover
                        if (message.equals("!undercover")) {   
                            String joinmsg = "";

                              String fileName = "join/"+sender+".txt";
                               String line = null;

                                try {
                                        FileReader fileReader = new FileReader(fileName);

                                        BufferedReader bufferedReader = new BufferedReader(fileReader);

                                        while((line = bufferedReader.readLine()) != null) {
                                            joinmsg = line;
                                            if (joinmsg.equals("undercover")){

                                            }else{
                                                 sendMessage(channel, "\"" + joinmsg + "\" - " + sender + "2013");
                                            }

                                        }	

                                        bufferedReader.close();			
                                    }
                                    catch(FileNotFoundException ex) {
                                        System.out.println(
                                            "Unable to open file '" + fileName + "'");				
                                    }
                                    catch(IOException ex) {
                                        System.out.println("Error reading file '" + fileName + "'");
                                    }
                            
                             if(joinmsg.equals("undercover")){
                                           try{
                                                FileWriter fstream = new FileWriter("join/"+sender+".txt");
                                                BufferedWriter out = new BufferedWriter(fstream);
                                                out.write("");

                                                out.close();
                                            }catch (Exception e){
                                            System.err.println("Error: " + e.getMessage());
                                            }
                                           
                                           sendMessage(channel, sender + " is no longer undercover!");
                             }
                             else{
                                            try{
                                                FileWriter fstream = new FileWriter("join/"+sender+".txt");
                                                BufferedWriter out = new BufferedWriter(fstream);
                                                out.write("undercover");

                                                out.close();
                                            }catch (Exception e){
                                            System.err.println("Error: " + e.getMessage());
                                            }
                                            
                                             sendMessage(channel, sender + " is now undercover!");
                             }
                             
			}
                      
          
                        
	}
	
          
          
          
          
          
          
          
          
          

          
          
          
          
          
          
          
	
	
	
	//Begrüssung
	protected void onJoin(final String channel, String sender, String login, String hostname){
           int rank = 0;
           String joinmsg = "";
            
        String fileName = "rank/"+sender+".txt";
        String line = null;

        try {
                FileReader fileReader = new FileReader(fileName);

                BufferedReader bufferedReader = new BufferedReader(fileReader);

                while((line = bufferedReader.readLine()) != null) {
                    rank = Integer.parseInt(line);
                }	

                bufferedReader.close();			
            }
            catch(FileNotFoundException ex) {
                System.out.println(
                    "Unable to open file '" + fileName + "'");				
            }
            catch(IOException ex) {
                System.out.println("Error reading file '" + fileName + "'");
            }
        
        
        
         fileName = "join/"+sender+".txt";
        line = null;

        try {
                FileReader fileReader = new FileReader(fileName);

                BufferedReader bufferedReader = new BufferedReader(fileReader);

                while((line = bufferedReader.readLine()) != null) {
                    joinmsg = line;
                    if (joinmsg.equals("undercover")){
                        
                    }else{
                         sendMessage(channel, "\"" + joinmsg + "\" - " + sender + " 2013");
                    }
                   
                }	

                bufferedReader.close();			
            }
            catch(FileNotFoundException ex) {
                System.out.println(
                    "Unable to open file '" + fileName + "'");				
            }
            catch(IOException ex) {
                System.out.println("Error reading file '" + fileName + "'");
            }
            
            
                       
            
            rank++;
            
          
          //Rank in Datei schreiben
           try{
                FileWriter fstream = new FileWriter("rank/"+sender+".txt");
                BufferedWriter out = new BufferedWriter(fstream);
                out.write(rank+"");
                
                out.close();
            }catch (Exception e){
            System.err.println("Error: " + e.getMessage());
            }
     if (joinmsg.equals("undercover")){
         
     }
     else{
        sendMessage(channel, "Welcome to the stream " + sender + "! FrankerZ [Rank " + rank + "]");
     }
     
     
     
     
     if(first == 0){
         //Automessage
                        ActionListener actListner = new ActionListener() {

                        @Override

                        public void actionPerformed(ActionEvent event) {

                            sendMessage(channel, "Welcome to the land of bad (flat) jokes, I'm your travel guide! Our journey starts irregular in the night (german time / UTC+1). Our voyage includes 'RPG Maker Firstlooks', 'Speedruns' or 'Just Random Games' in the beautiful languages german and english!");

                        }

                          };

                          Timer timer = new Timer(600000, actListner);

                          timer.start();
                          
           //Automessage
                        ActionListener actListner02 = new ActionListener() {

                        @Override

                        public void actionPerformed(ActionEvent event) {

                            sendMessage(channel, "Don't forget, to check out the description!");

                        }

                          };

                          Timer timer02 = new Timer(666666, actListner02);

                          timer02.start();               
                          
                          
                          first = 1;
     }
           
           
      }
      
      
      
      
     
	
	//Verabschiedung
	protected void onPart(String channel, String sender, String login, String hostname){
		sendMessage(channel, "Bye " + sender + "! We will miss you! RalpherZ"); 
	}
	
	protected void onQuit(String channel, String sender, String login, String hostname){
		sendMessage(channel, "Bye " + sender + "! We will miss you! RalpherZ"); 
	}

        
        

	
	
	
	
	
	
	
	
}